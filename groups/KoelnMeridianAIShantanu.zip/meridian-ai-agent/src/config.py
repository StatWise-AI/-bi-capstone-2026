"""
config.py
---------
Central configuration for the MERIDIAN AI Agent.

This file is provided by the instructor. Students generally should NOT need
to edit it, unless you want to add/remove a tradeable symbol.

SYMBOLS maps the human-readable name shown in the MERIDIAN dashboard to the
real ticker symbol used by Yahoo Finance (via the `yfinance` library). These
are REAL, live market tickers -- when you run data_pipeline.py you are
downloading actual historical price data, not synthetic/fake data.
"""

# The 9 focus symbols from the MERIDIAN dashboard (crypto, equities, forex,
# commodities) mapped to their Yahoo Finance ticker codes.
SYMBOLS = {
    "BTC/USDT": "BTC-USD",
    "ETH/USDT": "ETH-USD",
    "Apple": "AAPL",
    "Tesla": "TSLA",
    "Nvidia": "NVDA",
    "EUR/USD": "EURUSD=X",
    "GBP/USD": "GBPUSD=X",
    "Gold": "GC=F",
    "Crude Oil": "CL=F",
}

# Default data resolution and lookback window used when fetching data.
# 15m interval matches the MERIDIAN dashboard's advanced chart panel.
# Yahoo Finance only keeps intraday (15m) data for a limited lookback window
# (~60 days), which is why the default period is short.
DEFAULT_INTERVAL = "15m"
DEFAULT_PERIOD = "5d"

# Fallback interval/period pair for symbols or environments where intraday
# data is unavailable (e.g. some forex/futures tickers, weekends, rate limits).
FALLBACK_INTERVAL = "1d"
FALLBACK_PERIOD = "6mo"
