"""
evaluation.py
-------------
Lightweight tool for the project's "Evaluation" sub-task: log each AI read
with a timestamp, then later check whether the stance (Bullish/Bearish/
Neutral) matched what price actually did afterwards.

Provided by the instructor as a starting point. Unlike the other files in
src/, this one is intentionally simple -- feel free to extend it (e.g. more
detailed hit-rate breakdowns by symbol or confidence level) as part of your
own project write-up.
"""

import csv
from datetime import datetime, timezone
from pathlib import Path

LOG_FILE = Path(__file__).resolve().parent.parent / "data" / "eval_log.csv"
LOG_FILE.parent.mkdir(parents=True, exist_ok=True)

FIELDS = ["timestamp_utc", "symbol", "stance", "confidence", "close_price"]


def log_ai_read(symbol_display: str, ai_response: dict, close_price: float) -> None:
    """Append one row to data/eval_log.csv every time the AI assistant is used."""
    is_new = not LOG_FILE.exists()
    with open(LOG_FILE, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        if is_new:
            writer.writeheader()
        writer.writerow({
            "timestamp_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "symbol": symbol_display,
            "stance": ai_response.get("stance", "Neutral"),
            "confidence": ai_response.get("confidence", "Low"),
            "close_price": close_price,
        })


def compute_hit_rate(current_price_lookup: dict) -> dict:
    """
    Compare each logged read to the CURRENT price for that symbol
    (pass in a dict like {"Apple": 191.20, "BTC/USDT": 61000.0, ...}
    e.g. built from data_pipeline.fetch_all()).

    A "hit" means: Bullish stance and price is now higher, or Bearish stance
    and price is now lower. Neutral reads are excluded from the hit rate.

    Returns {"total": n, "hits": n, "hit_rate_pct": float}
    """
    if not LOG_FILE.exists():
        return {"total": 0, "hits": 0, "hit_rate_pct": 0.0}

    total, hits = 0, 0
    with open(LOG_FILE, newline="") as f:
        for row in csv.DictReader(f):
            symbol = row["symbol"]
            if symbol not in current_price_lookup:
                continue
            stance = row["stance"]
            if stance == "Neutral":
                continue
            logged_price = float(row["close_price"])
            current_price = current_price_lookup[symbol]
            total += 1
            went_up = current_price > logged_price
            if (stance == "Bullish" and went_up) or (stance == "Bearish" and not went_up):
                hits += 1

    hit_rate = (hits / total * 100) if total else 0.0
    return {"total": total, "hits": hits, "hit_rate_pct": round(hit_rate, 1)}
