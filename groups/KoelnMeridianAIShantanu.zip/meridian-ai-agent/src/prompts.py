"""
prompts.py
----------
Prompt templates for the AI decision-support agent described in the
project's "Planned Next Steps" (Section 4): an LLM reads the same data a
trader sees on the dashboard (price action, technical gauge, upcoming
economic events) and returns a plain-language read -- not an autonomous
buy/sell instruction.

Provided by the instructor. Students should not need to edit this file,
though you're welcome to tune wording once the pipeline works end-to-end.
"""

SYSTEM_PROMPT = """You are a market research assistant embedded in a trading \
dashboard called MERIDIAN. You help a trader interpret current price action, \
technical indicators, and upcoming macroeconomic events for one instrument \
at a time.

Rules you must always follow:
1. You are a RESEARCH AID, not a financial advisor. Never present your \
output as an instruction to buy or sell, and never claim certainty about \
future price movement.
2. Base your read only on the data provided in the user message. Do not \
invent price levels, news, or events that were not given to you.
3. Always surface risks and counter-arguments, not just the bullish or \
bearish case.
4. Respond with a single JSON object and nothing else -- no markdown \
fences, no preamble, no commentary outside the JSON.

The JSON object must have exactly these keys:
- "stance": one of "Bullish", "Bearish", "Neutral"
- "confidence": one of "Low", "Medium", "High"
- "key_factors": an array of 2-4 short strings supporting the stance
- "risks": an array of 2-4 short strings describing what could invalidate the stance
- "summary": a 2-3 sentence plain-language explanation, suitable for a trader \
to read at a glance
"""


def build_user_prompt(symbol_display: str, df, gauge: dict, economic_events=None) -> str:
    """
    Assemble the structured context block sent to the LLM.

    symbol_display: e.g. "Apple"
    df:             OHLCV DataFrame from data_pipeline.fetch_ohlcv
    gauge:          dict from indicators.aggregate_technical_gauge
    economic_events: optional list of strings, e.g.
                      ["Fri 14:30 UTC: US Non-Farm Payrolls", ...]
    """
    latest = df.iloc[-1]
    prev = df.iloc[-2] if len(df) > 1 else latest
    pct_change = ((latest["Close"] - prev["Close"]) / prev["Close"]) * 100 if prev["Close"] else 0.0

    recent_window = df.tail(20)
    recent_high = recent_window["High"].max()
    recent_low = recent_window["Low"].min()

    lines = [
        f"Instrument: {symbol_display}",
        f"Latest close: {latest['Close']:.4f}",
        f"Change vs previous bar: {pct_change:+.2f}%",
        f"Recent range (last {len(recent_window)} bars): low {recent_low:.4f} / high {recent_high:.4f}",
        "",
        "Technical gauge summary:",
        f"  Verdict: {gauge['verdict']} (buy votes: {gauge['buy']}, sell votes: {gauge['sell']}, neutral: {gauge['neutral']})",
    ]
    for name, vote in gauge["details"].items():
        lines.append(f"  - {name}: {vote}")

    lines.append(f"  RSI(14): {gauge['latest_values']['rsi']:.1f}")

    if economic_events:
        lines.append("")
        lines.append("Upcoming relevant economic events:")
        for event in economic_events:
            lines.append(f"  - {event}")
    else:
        lines.append("")
        lines.append("No economic calendar events were provided for this instrument.")

    lines.append("")
    lines.append("Based only on the data above, return the JSON object described in your instructions.")

    return "\n".join(lines)
