"""
llm_agent.py
------------
Calls the Claude API to turn the structured market context (from
data_pipeline.py + indicators.py + prompts.py) into a plain-language read,
per the project's "Model integration" and "Output design" sub-tasks.

Provided by the instructor. Students should not need to edit this file --
you will call get_ai_read() from the Streamlit app.

Requires an ANTHROPIC_API_KEY environment variable (see .env.example and
STUDENT_GUIDE.md for how to set this up).
"""

import json
import os

from anthropic import Anthropic

from src.prompts import SYSTEM_PROMPT, build_user_prompt

DEFAULT_MODEL = "claude-sonnet-5"


def _get_client() -> Anthropic:
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise RuntimeError(
            "ANTHROPIC_API_KEY is not set. Add it to your .env file "
            "(see .env.example) or your Streamlit secrets."
        )
    return Anthropic(api_key=api_key)


def get_ai_read(symbol_display: str, df, gauge: dict, economic_events=None,
                 model: str = DEFAULT_MODEL) -> dict:
    """
    Returns a dict with keys: stance, confidence, key_factors, risks, summary.
    Falls back to a safe "Neutral / Low confidence" response if the API call
    or JSON parsing fails, so the Streamlit app never crashes on a bad response.
    """
    client = _get_client()
    user_prompt = build_user_prompt(symbol_display, df, gauge, economic_events)

    try:
        response = client.messages.create(
            model=model,
            max_tokens=500,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_prompt}],
        )
        text = "".join(
            block.text for block in response.content if getattr(block, "type", None) == "text"
        )
        text = text.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        parsed = json.loads(text)

        for key in ("stance", "confidence", "key_factors", "risks", "summary"):
            if key not in parsed:
                raise ValueError(f"Missing key '{key}' in model response")

        return parsed

    except Exception as exc:  # noqa: BLE001
        return {
            "stance": "Neutral",
            "confidence": "Low",
            "key_factors": [],
            "risks": [f"AI read unavailable: {exc}"],
            "summary": (
                "The AI assistant could not produce a read for this instrument "
                "right now. Check your API key and connection, then try again."
            ),
        }


if __name__ == "__main__":
    # Quick manual test: run `python -m src.llm_agent` from the project root
    # (requires ANTHROPIC_API_KEY to be set).
    from src.data_pipeline import fetch_ohlcv
    from src.indicators import aggregate_technical_gauge

    df = fetch_ohlcv("Apple")
    gauge = aggregate_technical_gauge(df)
    result = get_ai_read("Apple", df, gauge)
    print(json.dumps(result, indent=2))
