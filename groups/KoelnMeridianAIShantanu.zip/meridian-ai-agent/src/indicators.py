"""
indicators.py
-------------
Technical analysis calculations, computed directly from real OHLCV data
(no external TA library required -- pure pandas/numpy so the logic is easy
to read and audit).

This recreates, in code you own, the same kind of "technical gauge" that the
MERIDIAN dashboard currently gets from the embedded TradingView widget --
which matters once you want the AI agent to reason over these numbers,
since an LLM can't read a TradingView widget directly.

Provided by the instructor. Students should not need to edit this file.
"""

import numpy as np
import pandas as pd


def compute_sma(series: pd.Series, window: int) -> pd.Series:
    return series.rolling(window=window).mean()


def compute_ema(series: pd.Series, window: int) -> pd.Series:
    return series.ewm(span=window, adjust=False).mean()


def compute_rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.rolling(window=period).mean()
    avg_loss = loss.rolling(window=period).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    rsi = 100 - (100 / (1 + rs))
    return rsi.fillna(50)  # neutral when undefined (e.g. flat prices)


def compute_macd(series: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9):
    ema_fast = compute_ema(series, fast)
    ema_slow = compute_ema(series, slow)
    macd_line = ema_fast - ema_slow
    signal_line = compute_ema(macd_line, signal)
    histogram = macd_line - signal_line
    return macd_line, signal_line, histogram


def compute_bollinger_bands(series: pd.Series, window: int = 20, num_std: float = 2.0):
    mid = compute_sma(series, window)
    std = series.rolling(window=window).std()
    upper = mid + num_std * std
    lower = mid - num_std * std
    return upper, mid, lower


def compute_atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high, low, close = df["High"], df["Low"], df["Close"]
    prev_close = close.shift(1)
    tr = pd.concat([
        high - low,
        (high - prev_close).abs(),
        (low - prev_close).abs(),
    ], axis=1).max(axis=1)
    return tr.rolling(window=period).mean()


def aggregate_technical_gauge(df: pd.DataFrame) -> dict:
    """
    Combine several indicators into a single Buy / Sell / Neutral verdict,
    similar in spirit to TradingView's "Technical Analysis" gauge.

    Returns a dict, e.g.:
    {
        "buy": 4, "sell": 1, "neutral": 2,
        "verdict": "Buy",
        "details": {
            "SMA20_vs_Price": "Buy",
            "RSI14": "Neutral",
            "MACD": "Buy",
            ...
        },
        "latest_values": {"close": 191.23, "rsi": 58.4, ...}
    }
    """
    close = df["Close"]
    votes = {}

    # Moving averages: price above -> bullish, below -> bearish
    for window in (20, 50):
        sma = compute_sma(close, window)
        if pd.notna(sma.iloc[-1]):
            votes[f"SMA{window}_vs_Price"] = "Buy" if close.iloc[-1] > sma.iloc[-1] else "Sell"

    # RSI
    rsi = compute_rsi(close)
    latest_rsi = rsi.iloc[-1]
    if latest_rsi > 60:
        votes["RSI14"] = "Buy"
    elif latest_rsi < 40:
        votes["RSI14"] = "Sell"
    else:
        votes["RSI14"] = "Neutral"

    # MACD
    macd_line, signal_line, _ = compute_macd(close)
    if pd.notna(macd_line.iloc[-1]) and pd.notna(signal_line.iloc[-1]):
        votes["MACD"] = "Buy" if macd_line.iloc[-1] > signal_line.iloc[-1] else "Sell"

    # Bollinger position
    upper, mid, lower = compute_bollinger_bands(close)
    if pd.notna(upper.iloc[-1]):
        if close.iloc[-1] >= upper.iloc[-1]:
            votes["Bollinger"] = "Sell"   # overbought
        elif close.iloc[-1] <= lower.iloc[-1]:
            votes["Bollinger"] = "Buy"    # oversold
        else:
            votes["Bollinger"] = "Neutral"

    buy = sum(1 for v in votes.values() if v == "Buy")
    sell = sum(1 for v in votes.values() if v == "Sell")
    neutral = sum(1 for v in votes.values() if v == "Neutral")

    if buy > sell and buy > neutral:
        verdict = "Buy"
    elif sell > buy and sell > neutral:
        verdict = "Sell"
    else:
        verdict = "Neutral"

    return {
        "buy": buy,
        "sell": sell,
        "neutral": neutral,
        "verdict": verdict,
        "details": votes,
        "latest_values": {
            "close": float(close.iloc[-1]),
            "rsi": float(latest_rsi),
        },
    }
