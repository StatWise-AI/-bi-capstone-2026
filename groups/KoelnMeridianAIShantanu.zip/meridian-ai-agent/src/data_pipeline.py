"""
data_pipeline.py
-----------------
Fetches REAL, live OHLCV (Open/High/Low/Close/Volume) market data for the
symbols defined in config.py, using the free `yfinance` library (which pulls
from Yahoo Finance).

This is the "real-world dataset" for the project: every time this script
runs, it downloads current market data -- there is no static/fake CSV to
maintain, and the dataset is always up to date.

Provided by the instructor. Students should not need to edit this file --
you will *call* the functions below from the Streamlit app, not rewrite them.
"""

from pathlib import Path
import pandas as pd
import yfinance as yf

from src.config import (
    SYMBOLS,
    DEFAULT_INTERVAL,
    DEFAULT_PERIOD,
    FALLBACK_INTERVAL,
    FALLBACK_PERIOD,
)

CACHE_DIR = Path(__file__).resolve().parent.parent / "data" / "cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)


def fetch_ohlcv(display_name: str, interval: str = DEFAULT_INTERVAL,
                 period: str = DEFAULT_PERIOD, use_cache: bool = True) -> pd.DataFrame:
    """
    Download OHLCV data for one symbol.

    display_name: the human-readable name, e.g. "Apple" (must be a key in SYMBOLS)
    interval:     bar size, e.g. "15m", "1h", "1d"
    period:       lookback window, e.g. "5d", "1mo", "6mo"
    use_cache:    if True, saves/reuses a local CSV copy in data/cache/

    Returns a pandas DataFrame indexed by datetime, with columns:
    Open, High, Low, Close, Volume
    """
    if display_name not in SYMBOLS:
        raise ValueError(
            f"Unknown symbol '{display_name}'. Valid options: {list(SYMBOLS.keys())}"
        )

    ticker = SYMBOLS[display_name]
    cache_file = CACHE_DIR / f"{ticker.replace('=', '_').replace('/', '_')}_{interval}.csv"

    df = yf.download(ticker, interval=interval, period=period, progress=False, auto_adjust=True)

    # Intraday data isn't always available (weekends, illiquid hours, some
    # forex/futures tickers). Fall back to a longer daily window so the app
    # never just breaks.
    if df is None or df.empty:
        df = yf.download(ticker, interval=FALLBACK_INTERVAL, period=FALLBACK_PERIOD,
                          progress=False, auto_adjust=True)

    if df.empty:
        raise RuntimeError(f"No data returned for {display_name} ({ticker}).")

    # yfinance sometimes returns MultiIndex columns for a single ticker; flatten them.
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)

    df = df.rename(columns=str.title)  # Open, High, Low, Close, Volume
    df.index.name = "Datetime"

    if use_cache:
        try:
            df.to_csv(cache_file)
        except OSError:
            pass  # caching is best-effort; never fail the app because of it

    return df


def fetch_all(interval: str = DEFAULT_INTERVAL, period: str = DEFAULT_PERIOD) -> dict:
    """
    Download OHLCV data for every symbol in config.SYMBOLS.
    Returns a dict: { display_name: DataFrame }
    """
    data = {}
    for name in SYMBOLS:
        try:
            data[name] = fetch_ohlcv(name, interval=interval, period=period)
        except Exception as exc:  # noqa: BLE001
            print(f"[data_pipeline] Skipping {name}: {exc}")
    return data


if __name__ == "__main__":
    # Quick manual test: run `python -m src.data_pipeline` from the project root.
    sample = fetch_ohlcv("Apple")
    print(sample.tail())
    print(f"\nFetched {len(sample)} rows for Apple.")
