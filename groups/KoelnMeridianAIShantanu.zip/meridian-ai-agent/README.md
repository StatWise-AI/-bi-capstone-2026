# MERIDIAN AI Assistant

Companion AI agent for the **MERIDIAN** live market terminal. This app adds
the "AI decision-support layer" described in the project's Section 4 (Planned
Next Steps): a trader picks a focus symbol, and the assistant reads the same
price data and technical gauge shown on the dashboard, then returns a
plain-language read — a stance, supporting factors, risks, and a confidence
level. It is a research aid, not an autonomous trading signal.

## Architecture

```
meridian-ai-agent/
├── app/
│   └── streamlit_app.py     # The Streamlit UI — students build/customize this
├── src/                     # Provided data + AI pipeline (do not need to rewrite)
│   ├── config.py            # Symbol list (9 instruments, real Yahoo Finance tickers)
│   ├── data_pipeline.py     # Downloads real OHLCV market data (yfinance)
│   ├── indicators.py        # SMA/EMA/RSI/MACD/Bollinger/ATR + technical gauge
│   ├── prompts.py           # System prompt + context-assembly for the LLM
│   ├── llm_agent.py         # Calls the Claude API, returns a structured read
│   └── evaluation.py        # Logs AI reads for later hit-rate evaluation
├── tests/
│   └── test_indicators.py   # Sanity tests for the indicator math
├── data/                    # Cached CSVs + evaluation log land here (gitignored)
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
└── STUDENT_GUIDE.md          # Step-by-step setup + deployment instructions
```

**Data flow:** `data_pipeline.py` (real market data) → `indicators.py`
(technical gauge) → `prompts.py` (context assembly) → `llm_agent.py` (Claude
API call) → `streamlit_app.py` (UI) → optionally logged by `evaluation.py`.

## What's already built for you

Everything in `src/` — the real-data pipeline, the technical indicator math,
the prompt design, and the Claude API integration — is provided. You are not
expected to write machine-learning or indicator code from scratch. Your work
is:

1. Building/customizing the Streamlit UI in `app/streamlit_app.py`.
2. Connecting this app to your existing MERIDIAN HTML dashboard (e.g. a
   "Launch AI Assistant" button/link pointing at your deployed Streamlit URL).
3. Deploying both pieces and pushing everything to the GitHub repository
   provided by your instructor.
4. (Optional/bonus) Extending `evaluation.py` to summarize hit-rate results,
   or wiring in a real economic-calendar feed.

See **STUDENT_GUIDE.md** for the full step-by-step walkthrough.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env             # then paste in your Anthropic API key
streamlit run app/streamlit_app.py
```

## Disclaimer

This tool is for educational/research purposes only. It does not place
trades, does not guarantee accuracy, and is not financial advice.
