# Student Guide: Building & Deploying the MERIDIAN AI Assistant

Follow these steps in order. Don't skip a step even if it seems obvious —
each one sets up something the next step needs.

---

## 0. Before you start

You will need:
- Python 3.10 or newer installed on your computer
- A free [GitHub](https://github.com) account
- Git installed (`git --version` in a terminal should show a version number)
- A code editor (VS Code is recommended)
- An Anthropic API key (Step 3 explains how to get one)

You do **not** need to know machine learning to complete this project. All
of the data-fetching, indicator-calculation, and AI-integration code is
already provided in the `src/` folder. Your job is to run it, understand it
at a high level, connect it to the dashboard, and deploy it.

---

## 1. Get the project files onto your computer

Your instructor will give you a link to a GitHub repository (either an empty
repo you push into, or a starter repo you clone). Two common cases:

**Case A — you were given an empty repository to push into:**
```bash
cd path/to/where/you/keep/projects
git clone <the-repo-url-your-instructor-gave-you>
cd <repo-folder-name>
```
Then copy all the files from this project package into that folder.

**Case B — you were given a repository that already contains these files:**
```bash
git clone <the-repo-url-your-instructor-gave-you>
cd <repo-folder-name>
```

Either way, you should end up with a folder containing `app/`, `src/`,
`tests/`, `README.md`, `requirements.txt`, etc.

---

## 2. Set up your Python environment

From inside the project folder:

```bash
python -m venv .venv
```

Activate it:
- macOS/Linux: `source .venv/bin/activate`
- Windows (PowerShell): `.venv\Scripts\Activate.ps1`

You'll know it worked because your terminal prompt will show `(.venv)` at
the start of the line.

Install the required packages:
```bash
pip install -r requirements.txt
```

---

## 3. Get an Anthropic API key

1. Go to https://console.anthropic.com and sign up / log in.
2. Create an API key (usually under "API Keys" in account settings).
3. Copy it somewhere safe — you won't be able to see the full key again.

**Never share this key or commit it to GitHub.** It's tied to a billing
account.

In your project folder, copy the example environment file:
```bash
cp .env.example .env
```
Open `.env` in your editor and paste your key in:
```
ANTHROPIC_API_KEY=sk-ant-your-actual-key-here
```
The `.env` file is already listed in `.gitignore`, so it will not be pushed
to GitHub.

---

## 4. Test the data pipeline

Before touching the app, confirm the real-data pipeline works on your
machine:

```bash
python -m src.data_pipeline
```

You should see the last few rows of real Apple stock price data printed to
your terminal. If this fails, it's almost always one of:
- No internet connection
- A typo if you edited `src/config.py`
- Yahoo Finance rate-limiting (wait a minute and try again)

Next, test the AI agent directly (this will use a small amount of your API
credit):
```bash
python -m src.llm_agent
```
You should see a JSON object printed with `stance`, `confidence`,
`key_factors`, `risks`, and `summary`.

---

## 5. Run the Streamlit app locally

```bash
streamlit run app/streamlit_app.py
```

This opens the app in your browser (usually at `http://localhost:8501`).
Try it:
1. Pick a symbol in the sidebar.
2. Click **Fetch latest data** — you should see a real candlestick chart and
   a technical gauge verdict.
3. Click **Get AI read** — you should see a structured Bullish/Bearish/
   Neutral read with factors and risks.

---

## 6. Understand the code layout (before you customize anything)

| Folder/file | What it does | Should you edit it? |
|---|---|---|
| `src/config.py` | List of tradeable symbols | Only if adding a new symbol |
| `src/data_pipeline.py` | Downloads real market data | No |
| `src/indicators.py` | Computes technical indicators | No |
| `src/prompts.py` | Builds the prompt sent to the AI | Only to tune wording, once everything works |
| `src/llm_agent.py` | Calls the Claude API | No |
| `src/evaluation.py` | Logs AI reads for later evaluation | Optional to extend |
| `app/streamlit_app.py` | The UI | **Yes — this is your main file** |

Spend some time reading through `src/` so you understand *what* data is
flowing into the AI, even though you're not rewriting that logic.

---

## 7. Customize the Streamlit app

This is where you add your own work on top of the provided pipeline. Ideas,
roughly in order of difficulty:

- Restyle the app to visually match your MERIDIAN dashboard's dark
  terminal theme (colors, fonts).
- Add a symbol comparison view (show two instruments' gauges side by side).
- Wire in a real economic calendar feed instead of the free-text box
  (this is a good place to practice calling another API).
- Add a history view using `src/evaluation.py`'s logged data, showing past
  AI reads for a symbol.

Keep committing to Git as you go (see Step 9) — don't wait until the end.

---

## 8. Connect the AI Assistant to your MERIDIAN dashboard

Once your Streamlit app is deployed (Step 10 gives you a live URL), add a
button or link in your MERIDIAN HTML dashboard that opens it — for example,
a new header button:

```html
<a href="https://your-app-name.streamlit.app" target="_blank" class="ai-assistant-btn">
  🤖 AI Assistant
</a>
```

Style it to match your existing terminal theme. This satisfies the "AI
assistant panel" requirement from Section 4 of your progress report, even
though the assistant runs as a separate app rather than an embedded iframe
(TradingView's widgets and Streamlit apps generally can't share one page
cleanly — a linked/new-tab launch is the standard approach here).

---

## 9. Push everything to GitHub

```bash
git add .
git commit -m "Add MERIDIAN AI Assistant"
git push origin main
```

Double-check on GitHub.com that:
- `.env` is **not** in the repo (if it is, you forgot `.gitignore` — remove
  it immediately and rotate your API key)
- `app/`, `src/`, `tests/`, `README.md`, `requirements.txt` are all present

---

## 10. Deploy to Streamlit Community Cloud

1. Go to https://share.streamlit.io and sign in with GitHub.
2. Click **New app**, select your repository, branch `main`, and set the
   main file path to `app/streamlit_app.py`.
3. Before deploying, open **Advanced settings → Secrets** and add:
   ```
   ANTHROPIC_API_KEY = "sk-ant-your-actual-key-here"
   ```
   (This is the cloud equivalent of your local `.env` file — the app reads
   from environment variables either way.)
4. Click **Deploy**. After a minute or two you'll get a public URL like
   `https://your-app-name.streamlit.app`.
5. Test it in an incognito browser window to confirm it works for someone
   without your local setup.

---

## 11. Final checklist before submission

- [ ] `python -m src.data_pipeline` runs without errors
- [ ] `pytest` passes (`pytest` from the project root)
- [ ] Streamlit app runs locally and produces an AI read for at least 3
      different symbols
- [ ] App is deployed and reachable at a public Streamlit URL
- [ ] MERIDIAN dashboard links out to the deployed AI Assistant
- [ ] `.env` is not committed to GitHub
- [ ] README updated with your deployed app's URL
- [ ] (Bonus) A short write-up of your evaluation results using
      `src/evaluation.py` — how often did the AI's stance match the actual
      subsequent price move?

---

## Troubleshooting

**"No data returned for X"** — Yahoo Finance intraday data can be flaky on
weekends/holidays or for some forex/futures tickers. The pipeline
automatically falls back to daily data; if it still fails, try again in a
few minutes.

**"ANTHROPIC_API_KEY is not set"** — check your `.env` file locally, or your
Secrets panel on Streamlit Community Cloud. There should be no quotes around
the key in `.env`, but quotes ARE required in the Streamlit Secrets box.

**AI read looks generic or always Neutral** — check `src/llm_agent.py`'s
fallback response in the terminal/logs; this usually means the API call
itself is failing (bad key, no credit, network issue), not a problem with
your data.
