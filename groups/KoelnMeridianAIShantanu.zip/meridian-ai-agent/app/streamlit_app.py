"""
streamlit_app.py
-----------------
MERIDIAN AI Assistant -- the companion app to the MERIDIAN dashboard.

This is the file students will spend the most time on. The ML/data-pipeline
logic already lives in src/ (provided). Your job is the UI: wiring up the
symbol picker, showing the data, calling the AI agent, and displaying the
result clearly -- plus any styling/UX polish and the deployment steps in
STUDENT_GUIDE.md.

Run locally with:  streamlit run app/streamlit_app.py
"""

import os
import sys
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from dotenv import load_dotenv

# Make sure `src` is importable whether this file is run from the project
# root or from inside app/.
sys.path.append(str(Path(__file__).resolve().parent.parent))

from src.config import SYMBOLS
from src.data_pipeline import fetch_ohlcv
from src.indicators import aggregate_technical_gauge
from src.llm_agent import get_ai_read
from src.evaluation import log_ai_read

load_dotenv()

st.set_page_config(page_title="MERIDIAN AI Assistant", page_icon="📈", layout="wide")

# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
st.sidebar.title("📈 MERIDIAN AI Assistant")
st.sidebar.caption("Companion app to the MERIDIAN live market terminal")

symbol_display = st.sidebar.selectbox("Focus symbol", list(SYMBOLS.keys()))
interval = st.sidebar.selectbox("Interval", ["15m", "1h", "1d"], index=0)
period = st.sidebar.selectbox("Lookback window", ["5d", "1mo", "3mo", "6mo"], index=0)

# Optional: paste upcoming economic events relevant to this symbol
# (in a fuller build this could be pulled from a live economic calendar API).
events_raw = st.sidebar.text_area(
    "Upcoming economic events (optional, one per line)",
    placeholder="e.g. Fri 14:30 UTC: US Non-Farm Payrolls",
)
economic_events = [line.strip() for line in events_raw.splitlines() if line.strip()] or None

fetch_clicked = st.sidebar.button("🔄 Fetch latest data", use_container_width=True)

st.sidebar.divider()
st.sidebar.caption(
    "⚠️ Research aid only. Not financial advice. The AI assistant does not "
    "place trades and does not guarantee future performance."
)

# ---------------------------------------------------------------------------
# Session state
# ---------------------------------------------------------------------------
if "df" not in st.session_state or fetch_clicked:
    try:
        with st.spinner(f"Fetching real market data for {symbol_display}..."):
            st.session_state.df = fetch_ohlcv(symbol_display, interval=interval, period=period)
            st.session_state.symbol_display = symbol_display
    except Exception as exc:  # noqa: BLE001
        st.error(f"Could not fetch data: {exc}")
        st.stop()

df = st.session_state.get("df")
current_symbol = st.session_state.get("symbol_display", symbol_display)

# ---------------------------------------------------------------------------
# Main layout
# ---------------------------------------------------------------------------
st.title(f"{current_symbol} — AI Market Read")

if df is None or df.empty:
    st.info("Click **Fetch latest data** in the sidebar to get started.")
    st.stop()

col_chart, col_gauge = st.columns([2, 1])

with col_chart:
    fig = go.Figure(data=[go.Candlestick(
        x=df.index, open=df["Open"], high=df["High"], low=df["Low"], close=df["Close"],
    )])
    fig.update_layout(height=420, margin=dict(l=10, r=10, t=30, b=10),
                       xaxis_rangeslider_visible=False)
    st.plotly_chart(fig, use_container_width=True)

gauge = aggregate_technical_gauge(df)

with col_gauge:
    st.subheader("Technical Gauge")
    verdict_color = {"Buy": "🟢", "Sell": "🔴", "Neutral": "🟡"}[gauge["verdict"]]
    st.metric("Verdict", f"{verdict_color} {gauge['verdict']}")
    st.caption(f"Buy votes: {gauge['buy']} · Sell votes: {gauge['sell']} · Neutral: {gauge['neutral']}")
    with st.expander("Indicator breakdown"):
        for name, vote in gauge["details"].items():
            st.write(f"**{name}:** {vote}")
        st.write(f"**RSI(14):** {gauge['latest_values']['rsi']:.1f}")

st.divider()

# ---------------------------------------------------------------------------
# AI Assistant panel
# ---------------------------------------------------------------------------
st.subheader("🤖 Ask the AI Assistant")
st.caption(
    "The assistant reads the same price and technical data shown above (plus "
    "any economic events you listed) and returns a plain-language read. "
    "It does not use any information beyond what's on this page."
)

if st.button("Get AI read", type="primary"):
    if not os.environ.get("ANTHROPIC_API_KEY"):
        st.error(
            "No ANTHROPIC_API_KEY found. Add it to a .env file locally, or to "
            "your app's Secrets if deployed on Streamlit Community Cloud. "
            "See STUDENT_GUIDE.md."
        )
    else:
        with st.spinner("Thinking..."):
            result = get_ai_read(current_symbol, df, gauge, economic_events)
            log_ai_read(current_symbol, result, close_price=float(df["Close"].iloc[-1]))
            st.session_state.ai_result = result

result = st.session_state.get("ai_result")
if result:
    stance_color = {"Bullish": "🟢", "Bearish": "🔴", "Neutral": "🟡"}.get(result["stance"], "⚪")
    c1, c2 = st.columns(2)
    c1.metric("Stance", f"{stance_color} {result['stance']}")
    c2.metric("Confidence", result["confidence"])

    st.write("**Summary**")
    st.write(result["summary"])

    kf_col, risk_col = st.columns(2)
    with kf_col:
        st.write("**Key factors**")
        for factor in result.get("key_factors", []):
            st.write(f"- {factor}")
    with risk_col:
        st.write("**Risks**")
        for risk in result.get("risks", []):
            st.write(f"- {risk}")

    st.caption(
        "This is a research aid generated by a language model, not financial "
        "advice, and not an instruction to trade."
    )
