"""
test_indicators.py
-------------------
Basic sanity tests for src/indicators.py, using synthetic (fake, predictable)
price data so the tests don't depend on the internet or real market hours.

Run with: pytest
"""

import numpy as np
import pandas as pd
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))

from src.indicators import (
    compute_sma, compute_ema, compute_rsi, compute_macd,
    compute_bollinger_bands, compute_atr, aggregate_technical_gauge,
)


def _fake_ohlcv(n=100, trend=0.5, seed=42):
    rng = np.random.default_rng(seed)
    close = np.cumsum(rng.normal(trend, 1.0, n)) + 100
    df = pd.DataFrame({
        "Open": close + rng.normal(0, 0.2, n),
        "High": close + abs(rng.normal(0.5, 0.3, n)),
        "Low": close - abs(rng.normal(0.5, 0.3, n)),
        "Close": close,
        "Volume": rng.integers(1000, 5000, n),
    })
    return df


def test_sma_length_matches_input():
    df = _fake_ohlcv()
    sma = compute_sma(df["Close"], 20)
    assert len(sma) == len(df)


def test_rsi_between_0_and_100():
    df = _fake_ohlcv()
    rsi = compute_rsi(df["Close"])
    valid = rsi.dropna()
    assert (valid >= 0).all() and (valid <= 100).all()


def test_macd_returns_three_series():
    df = _fake_ohlcv()
    macd_line, signal_line, hist = compute_macd(df["Close"])
    assert len(macd_line) == len(signal_line) == len(hist) == len(df)


def test_bollinger_upper_above_lower():
    df = _fake_ohlcv()
    upper, mid, lower = compute_bollinger_bands(df["Close"])
    valid_idx = upper.dropna().index
    assert (upper[valid_idx] >= lower[valid_idx]).all()


def test_atr_non_negative():
    df = _fake_ohlcv()
    atr = compute_atr(df)
    assert (atr.dropna() >= 0).all()


def test_gauge_has_expected_keys():
    df = _fake_ohlcv(n=80, trend=1.2)  # strong uptrend
    gauge = aggregate_technical_gauge(df)
    for key in ("buy", "sell", "neutral", "verdict", "details", "latest_values"):
        assert key in gauge
    assert gauge["verdict"] in ("Buy", "Sell", "Neutral")
